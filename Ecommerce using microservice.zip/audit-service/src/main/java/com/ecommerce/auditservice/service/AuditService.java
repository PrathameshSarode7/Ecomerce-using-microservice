package com.ecommerce.auditservice.service;

import com.ecommerce.auditservice.dto.AuditDTO;
import java.util.List;

public interface AuditService {
    AuditDTO logEvent(AuditDTO dto);
    List<AuditDTO> getAllLogs();
    AuditDTO getLogById(Long id);
    AuditDTO updateLog(Long id, AuditDTO dto);
    void deleteByRecordId(Long recordId);
}