package com.ecommerce.auditservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecommerce.auditservice.model.Audit;

@Repository
public interface AuditRepository extends JpaRepository<Audit, Long> {
	List<Audit> findByRecordId(Long recordId);
	void deleteByRecordId(Long recordId);
}