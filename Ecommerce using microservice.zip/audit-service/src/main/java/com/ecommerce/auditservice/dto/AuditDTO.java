package com.ecommerce.auditservice.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditDTO {
    private Long id;
    private String serviceName;
    private String operation;
    private Long recordId;
    private LocalDateTime timestamp;
    private String details;
}