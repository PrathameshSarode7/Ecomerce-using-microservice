package com.ecommerce.auditservice.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.auditservice.dto.AuditDTO;
import com.ecommerce.auditservice.exceptions.AuditNotFoundException;
import com.ecommerce.auditservice.model.Audit;
import com.ecommerce.auditservice.repository.AuditRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class AuditServiceImpl implements AuditService {

    private final AuditRepository auditRepository;

    @Override
    public AuditDTO logEvent(AuditDTO dto) {
        if (dto.getOperation() == null) {
            dto.setOperation("GENERAL_AUDIT");
        }

        Audit audit = Audit.builder()
                .serviceName(dto.getServiceName())
                .operation(dto.getOperation())
                .recordId(dto.getRecordId())
                .details(dto.getDetails())
                .timestamp(LocalDateTime.now())
                .build();

        return toDTO(auditRepository.save(audit));
    }

    @Override
    public AuditDTO updateLog(Long id, AuditDTO dto) {
        Audit audit = auditRepository.findById(id)
                .orElseThrow(() -> new AuditNotFoundException("Log not found with id: " + id));

        audit.setServiceName(dto.getServiceName());
        audit.setOperation(dto.getOperation());
        audit.setRecordId(dto.getRecordId());
        audit.setDetails(dto.getDetails());

        Audit updated = auditRepository.save(audit);
        return toDTO(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public AuditDTO getLogById(Long id) {
        return auditRepository.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new AuditNotFoundException("Log not found with id: " + id));
    }

    @Override
    public void deleteByRecordId(Long id) {
        if (!auditRepository.existsById(id)) {
            throw new AuditNotFoundException("Record not found with id: " + id);
        }
        auditRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditDTO> getAllLogs() {
        List<Audit> logs = auditRepository.findAll();

        return logs.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    private AuditDTO toDTO(Audit entity) {
        return AuditDTO.builder()
                .id(entity.getId())
                .serviceName(entity.getServiceName())
                .operation(entity.getOperation())
                .recordId(entity.getRecordId())
                .timestamp(entity.getTimestamp())
                .details(entity.getDetails())
                .build();
    }
}