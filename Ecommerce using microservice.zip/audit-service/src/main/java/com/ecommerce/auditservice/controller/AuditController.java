package com.ecommerce.auditservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.auditservice.dto.AuditDTO;
import com.ecommerce.auditservice.service.AuditService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api")
@Tag(name = "Audit Controller", description = "Endpoints for managing audit logs")
@CrossOrigin(origins = { 
			
		"http://localhost:8765",
		"http://localhost:8085",					
						
	}, allowCredentials = "true")
public class AuditController {

    @Autowired
    private AuditService auditService;

    @PostMapping
    @PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
    @Operation(summary = "Log a new event")
    public ResponseEntity<AuditDTO> logEvent(@RequestBody AuditDTO dto) {
        return new ResponseEntity<>(auditService.logEvent(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
    @Operation(summary = "Get log by Database ID")
    public ResponseEntity<AuditDTO> getLogById(@PathVariable Long id) {
        return ResponseEntity.ok(auditService.getLogById(id));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
    @Operation(summary = "Update log information")
    public ResponseEntity<AuditDTO> updateLog(@PathVariable Long id, @RequestBody AuditDTO dto) {
        return ResponseEntity.ok(auditService.updateLog(id, dto));
    }

    @GetMapping("/search")
    @PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
    @Operation(summary = "Find all audit logs")
    public ResponseEntity<List<AuditDTO>> getAllLogs() {
        List<AuditDTO> logs = auditService.getAllLogs();
        
        if (logs.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(logs);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
    @Operation(summary = "Remove log entry")
    public ResponseEntity<Void> deleteLog(@PathVariable Long id) {
        auditService.deleteByRecordId(id);
        return ResponseEntity.noContent().build();
    }
}