package com.ecommerce.inventoryservice.services;

import com.ecommerce.inventoryservice.dto.InventoryDTO;

public interface InventoryService {
    InventoryDTO addInventory(InventoryDTO dto); 
    InventoryDTO getInventoryByItemId(Long itemId); 
    InventoryDTO updateInventory(Long id, InventoryDTO dto); 
    void deleteInventory(Long id); 
}