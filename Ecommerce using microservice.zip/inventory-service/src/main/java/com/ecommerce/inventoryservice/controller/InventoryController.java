package com.ecommerce.inventoryservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

import com.ecommerce.inventoryservice.dto.InventoryDTO;
import com.ecommerce.inventoryservice.services.InventoryService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class InventoryController {

	@Autowired
	private InventoryService inventoryService;
	
	@Autowired
	private RestClient restClient;
	
	@Value("${itemUrl}")
	private String itemUrl;
	
	@PostMapping
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Add inventory for an item")
	public ResponseEntity<String> addInventory(@RequestParam Long itemId, @RequestBody InventoryDTO dto, @RequestHeader("Authorization") String authHeader) {
		if(restClient.get().uri(itemUrl,itemId).header("Authorization", authHeader).retrieve().body(Boolean.class)) {
			dto.setItemId(itemId);
			inventoryService.addInventory(dto);
			return new ResponseEntity<String>("Inventory added", HttpStatus.CREATED);
		}
		else {
			return new ResponseEntity<String>("Please enter valid Item Id!!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	@GetMapping("/item/{itemId}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "View inventory levels for a specific item")
	public ResponseEntity<InventoryDTO> getInventoryByItemId(@PathVariable Long itemId) {
		return ResponseEntity.ok(inventoryService.getInventoryByItemId(itemId));
	}

	@PutMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Update inventory records")
	public ResponseEntity<InventoryDTO> updateInventory(@PathVariable Long id, @RequestBody InventoryDTO inventoryDTO) {
		return ResponseEntity.ok(inventoryService.updateInventory(id, inventoryDTO));
	}

	@DeleteMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Remove inventory records")
	public ResponseEntity<Void> deleteInventory(@PathVariable Long id) {
		inventoryService.deleteInventory(id);
		return ResponseEntity.noContent().build();
	}
}