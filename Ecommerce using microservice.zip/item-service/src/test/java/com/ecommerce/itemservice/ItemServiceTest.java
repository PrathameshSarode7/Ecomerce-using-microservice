package com.ecommerce.itemservice;

import com.ecommerce.itemservice.dto.ItemDTO;
import com.ecommerce.itemservice.exception.ItemNotFoundException;
import com.ecommerce.itemservice.model.Item;
import com.ecommerce.itemservice.repository.ItemRepository;
import com.ecommerce.itemservice.service.ItemServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ItemServiceTest {

    @Mock
    private ItemRepository itemRepository;

    @InjectMocks
    private ItemServiceImpl itemService;

    private Item sampleItem;
    private ItemDTO sampleDTO;

    @BeforeEach
    void setUp() {
        sampleItem = Item.builder()
                .id(1L)
                .name("Wireless Mouse")
                .description("Ergonomic wireless mouse")
                .category("Electronics")
                .createdAt(LocalDateTime.now())
                .build();

        sampleDTO = ItemDTO.builder()
                .name("Wireless Mouse")
                .description("Ergonomic wireless mouse")
                .category("Electronics")
                .build();
    }

    @Test
    void createItem_ShouldReturnCreatedItem() {
    	// Whenever the service calls save(), return sampleItem
    	
        when(itemRepository.save(any(Item.class))).thenReturn(sampleItem);
        ItemDTO result = itemService.createItem(sampleDTO);
        assertThat(result.getName()).isEqualTo("Wireless Mouse");
        assertThat(result.getCategory()).isEqualTo("Electronics");
        verify(itemRepository, times(1)).save(any(Item.class));
    }

    @Test
    void getItemById_WhenExists_ShouldReturnItem() {
        when(itemRepository.findById(1L)).thenReturn(Optional.of(sampleItem));
        ItemDTO result = itemService.getItemById(1L);
        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getName()).isEqualTo("Wireless Mouse");
    }

    @Test
    void getItemById_WhenNotExists_ShouldThrowException() {
        when(itemRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> itemService.getItemById(99L))
                .isInstanceOf(ItemNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    void getAllItems_ShouldReturnList() {
        when(itemRepository.findAll()).thenReturn(List.of(sampleItem));
        List<ItemDTO> result = itemService.getAllItems();
        assertThat(result).hasSize(1);
    }

    @Test
    void deleteItem_WhenExists_ShouldDelete() {
        when(itemRepository.existsById(1L)).thenReturn(true);
        itemService.deleteItem(1L);
        verify(itemRepository, times(1)).deleteById(1L);
    }

    @Test
    void deleteItem_WhenNotExists_ShouldThrow() {
        when(itemRepository.existsById(99L)).thenReturn(false);
        assertThatThrownBy(() -> itemService.deleteItem(99L))
                .isInstanceOf(ItemNotFoundException.class);
    }
}
