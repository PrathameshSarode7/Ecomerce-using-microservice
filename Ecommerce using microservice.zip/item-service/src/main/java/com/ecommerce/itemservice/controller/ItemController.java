package com.ecommerce.itemservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.itemservice.dto.ItemDTO;
import com.ecommerce.itemservice.service.ItemService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/items")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class ItemController {

	@Autowired
	private ItemService itemService;

	@PostMapping
	@PreAuthorize("hasAuthority('SCOPE_sre')")
	@Operation(summary = "Create a new item", security = @SecurityRequirement(name = "keycloakSRE"))
	public ResponseEntity<ItemDTO> createItem(@RequestBody ItemDTO itemDTO) {
		ItemDTO savedItem = itemService.createItem(itemDTO);
		return new ResponseEntity<>(savedItem, HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre','SCOPE_devopsengineer')")
	public ResponseEntity<ItemDTO> getItemById(@PathVariable Long id) {
		return ResponseEntity.ok(itemService.getItemById(id));
	}

	@PutMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Update item", security = @SecurityRequirement(name = "keycloakSRE"))
	public ResponseEntity<ItemDTO> updateItem(@PathVariable Long id, @RequestBody ItemDTO itemDTO) {
		return ResponseEntity.ok(itemService.updateItem(id, itemDTO));
	}

	@DeleteMapping("/{id}")
	@PreAuthorize("hasAuthority('SCOPE_sre')")
	@Operation(summary = "Delete an item", security = @SecurityRequirement(name = "keycloakSRE"))
	public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
		itemService.deleteItem(id);
		return ResponseEntity.noContent().build();
	}
	@GetMapping
    @PreAuthorize("hasAnyAuthority('SCOPE_sre','SCOPE_devopsengineer')")
    @Operation(summary = "Get all items")
    public ResponseEntity<List<ItemDTO>> getAllItems() {
        return ResponseEntity.ok(itemService.getAllItems());
    }

    @GetMapping("/category/{category}")
    @PreAuthorize("hasAnyAuthority('SCOPE_sre','SCOPE_devopsengineer')")
    @Operation(summary = "Get items by category")
    public ResponseEntity<List<ItemDTO>> getItemsByCategory(@PathVariable String category) {
        return ResponseEntity.ok(itemService.getItemsByCategory(category));
    }
    
    @GetMapping("/checkItem/{itemId}")
    public boolean checkItem(@PathVariable Long itemId) {
    	if(itemService.checkItem(itemId)) {
    		return true;
    	} else {
    		return false;
    	}
    }
}
