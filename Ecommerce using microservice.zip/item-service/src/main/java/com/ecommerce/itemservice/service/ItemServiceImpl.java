 package com.ecommerce.itemservice.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.itemservice.dto.ItemDTO;
import com.ecommerce.itemservice.exception.ItemNotFoundException;
import com.ecommerce.itemservice.model.Item;
import com.ecommerce.itemservice.repository.ItemRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ItemServiceImpl implements ItemService {

    private final ItemRepository itemRepository;

    @Override
    public ItemDTO createItem(ItemDTO itemDTO) {
        log.info("Creating new item: {}", itemDTO.getName());
        Item item = Item.builder()
                .name(itemDTO.getName())
                .description(itemDTO.getDescription())
                .category(itemDTO.getCategory())
                .createdAt(LocalDateTime.now())
                .build();
        Item saved = itemRepository.save(item);
        log.info("Item created with id: {}", saved.getId());
        return toDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public ItemDTO getItemById(Long id) {
        log.info("Fetching item with id: {}", id);
        Item item = itemRepository.findById(id)
                .orElseThrow(() -> new ItemNotFoundException(id));
        return toDTO(item);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ItemDTO> getAllItems() {
        log.info("Fetching all items");
        return itemRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ItemDTO> getItemsByCategory(String category) {
        log.info("Fetching items by category: {}", category);
        return itemRepository.findByCategory(category).stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    public ItemDTO updateItem(Long id, ItemDTO itemDTO) {
        log.info("Updating item with id: {}", id);
        Item item = itemRepository.findById(id)
                .orElseThrow(() -> new ItemNotFoundException(id));
        item.setName(itemDTO.getName());
        item.setDescription(itemDTO.getDescription());
        item.setCategory(itemDTO.getCategory());
        Item updated = itemRepository.save(item);
        log.info("Item updated: {}", id);
        return toDTO(updated);
    }

    @Override
    public void deleteItem(Long id) {
        log.info("Deleting item with id: {}", id);
        if (!itemRepository.existsById(id)) {
            throw new ItemNotFoundException(id);
        }
        itemRepository.deleteById(id);
        log.info("Item deleted: {}", id);
    }
    

    private ItemDTO toDTO(Item item) {
        return ItemDTO.builder()
                .id(item.getId())
                .name(item.getName())
                .description(item.getDescription())
                .category(item.getCategory())
                .createdAt(item.getCreatedAt())
                .build();
    }

	@Override
	public boolean checkItem(Long id) {
		// TODO Auto-generated method stub
		if(itemRepository.existsById(id)) {
			return true;
		} else {
		return false;
		}
	}
}
