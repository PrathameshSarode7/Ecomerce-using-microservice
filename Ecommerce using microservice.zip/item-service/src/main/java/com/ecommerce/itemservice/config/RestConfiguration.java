package com.ecommerce.itemservice.config;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;
 
@Configuration
//Here is a tool for making HTTP calls to other services
public class RestConfiguration {
	@Bean
	public RestClient getRestClient() {
		return RestClient.create();

	}
 
}

 