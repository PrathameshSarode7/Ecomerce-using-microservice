package com.ecommerce.itemservice.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemDTO {

	private Long id;

	@NotBlank(message = "Name is required")
	@Size(max = 150, message = "Name must not exceed 150 characters")
	private String name;

	private String description;

	@NotBlank(message = "Category is required")
	@Size(max = 100, message = "Category must not exceed 100 characters")
	private String category;

	private LocalDateTime createdAt;
}
