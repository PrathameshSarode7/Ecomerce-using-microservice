package com.cognizant.gatway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayauthorizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
