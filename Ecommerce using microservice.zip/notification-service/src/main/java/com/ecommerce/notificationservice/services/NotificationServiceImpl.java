package com.ecommerce.notificationservice.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.notificationservice.dto.NotificationDTO;
import com.ecommerce.notificationservice.exceptions.NotificationNotFoundException;
import com.ecommerce.notificationservice.model.Notification;
import com.ecommerce.notificationservice.repository.NotificationRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;

    @Override
    public NotificationDTO createNotification(NotificationDTO dto) {
        if (dto.getEventType() == null) {
            dto.setEventType("DEFAULT_TYPE");
        }
        
        Notification notification = Notification.builder()
                .recipient(dto.getRecipient())
                .message(dto.getMessage())
                .eventType(dto.getEventType())
                .sentAt(LocalDateTime.now())
                .build();
                
        return toDTO(notificationRepository.save(notification));
    }

    @Override
    public NotificationDTO updateNotification(Long id, NotificationDTO dto) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new NotificationNotFoundException("Notification not found with id: " + id));

        notification.setRecipient(dto.getRecipient());
        notification.setMessage(dto.getMessage());
        
        if (dto.getEventType() != null) {
            notification.setEventType(dto.getEventType());
        }

        Notification updated = notificationRepository.save(notification);
        return toDTO(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public NotificationDTO getNotificationById(Long id) {
        return notificationRepository.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new NotificationNotFoundException("Notification not found with id: " + id));
    }

    @Override
    public void deleteNotification(Long id) {
        if (!notificationRepository.existsById(id)) {
            throw new NotificationNotFoundException("Record not found with id: " + id);
        }
        notificationRepository.deleteById(id);
    }

    private NotificationDTO toDTO(Notification entity) {
        return NotificationDTO.builder()
                .id(entity.getId())
                .recipient(entity.getRecipient())
                .message(entity.getMessage())
                .eventType(entity.getEventType())
                .sentAt(entity.getSentAt())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationDTO> getNotificationsByEventType(String eventType) {
        List<Notification> notifications = notificationRepository.findByEventType(eventType);
        
        return notifications.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }
}