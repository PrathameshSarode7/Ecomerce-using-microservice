package com.ecommerce.notificationservice.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationDTO {
    private Long id;
    @NotNull(message = "Recipient is required")
    private String recipient;
    @NotNull(message = "Message content is required")
    private String message;
    private String eventType;
    private LocalDateTime sentAt;
}