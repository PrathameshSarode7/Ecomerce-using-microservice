package com.ecommerce.notificationservice.services;

import java.util.List;

import com.ecommerce.notificationservice.dto.NotificationDTO;

public interface NotificationService {
    NotificationDTO createNotification(NotificationDTO dto);
    NotificationDTO getNotificationById(Long id);
    NotificationDTO updateNotification(Long id, NotificationDTO dto);
    List<NotificationDTO> getNotificationsByEventType(String eventType);
    void deleteNotification(Long id);
}