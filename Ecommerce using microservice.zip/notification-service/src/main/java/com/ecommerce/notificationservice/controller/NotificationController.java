package com.ecommerce.notificationservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.notificationservice.dto.NotificationDTO;
import com.ecommerce.notificationservice.services.NotificationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
@Tag(name = "Notification Controller", description = "Endpoints for managing notifications")
public class NotificationController {

	@Autowired
	private NotificationService notificationService;

	@PostMapping
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Log/Send a new notification")
	public ResponseEntity<NotificationDTO> createNotification(@RequestBody NotificationDTO dto) {
		return new ResponseEntity<>(notificationService.createNotification(dto), HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Get notification details")
	public ResponseEntity<NotificationDTO> getNotificationById(@PathVariable Long id) {
		return ResponseEntity.ok(notificationService.getNotificationById(id));
	}

	@PutMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Update notification details")
	public ResponseEntity<NotificationDTO> updateNotification(@PathVariable Long id, @RequestBody NotificationDTO dto) {
		return ResponseEntity.ok(notificationService.updateNotification(id, dto));
	}

	@GetMapping("/search")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Find notifications by event type")
	public ResponseEntity<List<NotificationDTO>> getNotificationsByEventType(@RequestParam String eventType) {
		List<NotificationDTO> notifications = notificationService.getNotificationsByEventType(eventType);
		
		if (notifications.isEmpty()) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(notifications);
	}

	@DeleteMapping("/{id}")
	@PreAuthorize("hasAnyAuthority('SCOPE_sre', 'SCOPE_devopsengineer')")
	@Operation(summary = "Delete notification log")
	public ResponseEntity<Void> deleteNotification(@PathVariable Long id) {
		notificationService.deleteNotification(id);
		return ResponseEntity.noContent().build();
	}
}